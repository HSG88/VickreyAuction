``cube.py``: basic example computing a cube
===========================================

.. automodule:: examples.cube
    :members:
    :special-members:
    :undoc-members:
    :show-inheritance:
