``gc.py``: execute a given binary circuit
=========================================

.. automodule:: examples.gc
    :members:
    :special-members:
    :undoc-members:
    :show-inheritance:
