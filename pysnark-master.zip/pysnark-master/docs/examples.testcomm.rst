``testcomm.py``: tests with committed data
==========================================

.. automodule:: examples.testcomm
    :members:
    :special-members:
    :undoc-members:
    :show-inheritance:
