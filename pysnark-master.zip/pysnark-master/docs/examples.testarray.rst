``tesarray.py``: test array functionality
=========================================

.. automodule:: examples.testarray
    :members:
    :special-members:
    :undoc-members:
    :show-inheritance:
