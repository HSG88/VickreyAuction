``kaplanmeier.py``: execute statistical test on survival data
==============================================================

.. automodule:: examples.kaplanmeier
    :members:
    :special-members:
    :undoc-members:
    :show-inheritance:
