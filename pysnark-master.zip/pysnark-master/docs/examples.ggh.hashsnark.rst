``hashsnark.py``: tests hash function
=====================================

.. automodule:: examples.ggh.hashsnark
    :members:
    :special-members:
    :undoc-members:
    :show-inheritance:
