pysnark\.atexitmaybe module
===========================

.. automodule:: pysnark.atexitmaybe
    :members:
    :special-members:
    :undoc-members:
    :show-inheritance:
